@echo off
title Online Examination System (React + FastAPI)
echo Starting Online Examination System...
start "" http://127.0.0.1:8000
python run.py
pause
