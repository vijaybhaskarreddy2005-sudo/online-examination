from pydantic import BaseModel, EmailStr, Field
from typing import List, Dict, Optional, Any

class UserRegister(BaseModel):
    name: str = Field(..., min_length=2, max_length=100)
    email: str = Field(...)
    password: str = Field(..., min_length=6)
    role: str = Field("student", pattern="^(student|teacher)$")

class UserLogin(BaseModel):
    email: str
    password: str

class UserResponse(BaseModel):
    id: int
    name: str
    email: str
    role: str
    created_at: str

class TokenResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"
    user: UserResponse

class QuestionCreate(BaseModel):
    question_text: str
    options: List[str] = Field(..., min_length=2, max_length=6)
    correct_option_index: int = Field(..., ge=0)
    marks: int = Field(1, ge=1)
    explanation: Optional[str] = ""

class QuestionPublic(BaseModel):
    id: int
    question_text: str
    options: List[str]
    marks: int

class QuestionDetailed(BaseModel):
    id: int
    question_text: str
    options: List[str]
    correct_option_index: int
    marks: int
    explanation: Optional[str] = ""

class ExamCreate(BaseModel):
    title: str = Field(..., min_length=3, max_length=200)
    description: Optional[str] = ""
    category: str = "General"
    duration_minutes: int = Field(15, ge=1, le=300)
    passing_score: int = Field(60, ge=1, le=100)
    questions: Optional[List[QuestionCreate]] = []

class ExamSummary(BaseModel):
    id: int
    title: str
    description: Optional[str]
    category: str
    duration_minutes: int
    passing_score: int
    created_by: int
    creator_name: Optional[str] = ""
    question_count: int
    total_marks: int
    created_at: str

class ExamTakeDetail(BaseModel):
    id: int
    title: str
    description: Optional[str]
    category: str
    duration_minutes: int
    passing_score: int
    questions: List[QuestionPublic]
    total_marks: int

class ExamSubmissionRequest(BaseModel):
    answers: Dict[str, int] # question_id (as str) -> selected option index (0..3)
    cheat_warnings_count: int = 0

class AnswerReview(BaseModel):
    question_id: int
    question_text: str
    options: List[str]
    selected_option_index: Optional[int]
    correct_option_index: int
    is_correct: bool
    marks_awarded: int
    total_marks: int
    explanation: Optional[str]

class SubmissionResult(BaseModel):
    id: int
    exam_id: int
    exam_title: str
    user_id: int
    user_name: str
    score: int
    total_marks: int
    percentage: float
    status: str
    cheat_warnings_count: int
    submitted_at: str
    review: Optional[List[AnswerReview]] = []
