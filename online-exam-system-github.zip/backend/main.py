import os
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
from backend.database import init_db
from backend.routers import auth, exams, submissions

app = FastAPI(
    title="Online Examination System API",
    description="Full-featured FastAPI + React Examination Engine with timer, auto-grading, proctoring warnings, and analytics.",
    version="1.0.0"
)

# CORS setup
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Initialize database schema and default seed data on startup
@app.on_event("startup")
def on_startup():
    init_db()

# Include API Routers
app.include_router(auth.router)
app.include_router(exams.router)
app.include_router(submissions.router)

@app.get("/api/health")
def health_check():
    return {"status": "online", "system": "Online Examination System", "version": "1.0.0"}

# Static and SPA frontend routing
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
STATIC_DIR = os.path.join(BASE_DIR, "static")

if os.path.exists(STATIC_DIR):
    app.mount("/static", StaticFiles(directory=STATIC_DIR), name="static")

@app.get("/")
def serve_index():
    index_path = os.path.join(STATIC_DIR, "index.html")
    if os.path.exists(index_path):
        return FileResponse(index_path)
    return {"message": "Online Examination API is running. Visit /docs for Swagger UI."}
