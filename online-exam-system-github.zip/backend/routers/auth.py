from fastapi import APIRouter, Depends, HTTPException, status
import sqlite3
from backend.database import get_db
from backend.auth import verify_password, get_password_hash, create_access_token, get_current_user
from backend.models import UserRegister, UserLogin, TokenResponse, UserResponse

router = APIRouter(prefix="/api/auth", tags=["Authentication"])

@router.post("/register", response_model=TokenResponse)
def register(user_data: UserRegister, db: sqlite3.Connection = Depends(get_db)):
    cursor = db.cursor()
    cursor.execute("SELECT id FROM users WHERE email = ?;", (user_data.email.lower().strip(),))
    existing = cursor.fetchone()
    if existing:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="An account with this email already exists."
        )

    hashed = get_password_hash(user_data.password)
    cursor.execute("""
    INSERT INTO users (name, email, password_hash, role)
    VALUES (?, ?, ?, ?);
    """, (user_data.name.strip(), user_data.email.lower().strip(), hashed, user_data.role))
    db.commit()

    user_id = cursor.lastrowid
    cursor.execute("SELECT id, name, email, role, created_at FROM users WHERE id = ?;", (user_id,))
    row = cursor.fetchone()

    token = create_access_token({"sub": str(user_id), "role": row["role"]})
    return {
        "access_token": token,
        "token_type": "bearer",
        "user": {
            "id": row["id"],
            "name": row["name"],
            "email": row["email"],
            "role": row["role"],
            "created_at": str(row["created_at"])
        }
    }

@router.post("/login", response_model=TokenResponse)
def login(creds: UserLogin, db: sqlite3.Connection = Depends(get_db)):
    cursor = db.cursor()
    cursor.execute("SELECT * FROM users WHERE email = ?;", (creds.email.lower().strip(),))
    user = cursor.fetchone()

    if not user or not verify_password(creds.password, user["password_hash"]):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid email or password"
        )

    token = create_access_token({"sub": str(user["id"]), "role": user["role"]})
    return {
        "access_token": token,
        "token_type": "bearer",
        "user": {
            "id": user["id"],
            "name": user["name"],
            "email": user["email"],
            "role": user["role"],
            "created_at": str(user["created_at"])
        }
    }

@router.post("/demo-login/{role}", response_model=TokenResponse)
def demo_login(role: str, db: sqlite3.Connection = Depends(get_db)):
    role = role.lower()
    if role not in ["student", "teacher"]:
        raise HTTPException(status_code=400, detail="Role must be 'student' or 'teacher'")

    cursor = db.cursor()
    email = "teacher@exam.com" if role == "teacher" else "student@exam.com"
    cursor.execute("SELECT * FROM users WHERE email = ?;", (email,))
    user = cursor.fetchone()

    if not user:
        raise HTTPException(status_code=404, detail="Demo account not found")

    token = create_access_token({"sub": str(user["id"]), "role": user["role"]})
    return {
        "access_token": token,
        "token_type": "bearer",
        "user": {
            "id": user["id"],
            "name": user["name"],
            "email": user["email"],
            "role": user["role"],
            "created_at": str(user["created_at"])
        }
    }

@router.get("/me", response_model=UserResponse)
def get_me(current_user: dict = Depends(get_current_user)):
    return current_user
