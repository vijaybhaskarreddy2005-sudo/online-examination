import json
import sqlite3
from typing import List, Dict, Any
from fastapi import APIRouter, Depends, HTTPException, status
from backend.database import get_db
from backend.auth import get_current_user, require_teacher
from backend.models import ExamSubmissionRequest, SubmissionResult, AnswerReview

router = APIRouter(prefix="/api/submissions", tags=["Submissions"])

@router.post("/exam/{exam_id}", response_model=SubmissionResult)
def submit_exam(
    exam_id: int,
    submission_data: ExamSubmissionRequest,
    current_user: dict = Depends(get_current_user),
    db: sqlite3.Connection = Depends(get_db)
):
    cursor = db.cursor()
    cursor.execute("SELECT * FROM exams WHERE id = ?;", (exam_id,))
    exam = cursor.fetchone()
    if not exam:
        raise HTTPException(status_code=404, detail="Exam not found")

    cursor.execute("""
    SELECT id, question_text, options_json, correct_option_index, marks, explanation
    FROM questions WHERE exam_id = ? ORDER BY id ASC;
    """, (exam_id,))
    questions = cursor.fetchall()

    if not questions:
        raise HTTPException(status_code=400, detail="Cannot submit an exam with no questions.")

    total_marks = 0
    earned_score = 0
    review_list = []

    # Map string question id from payload to integer
    user_answers = submission_data.answers

    for q in questions:
        qid = q["id"]
        q_marks = q["marks"]
        correct_idx = q["correct_option_index"]
        options = json.loads(q["options_json"]) if isinstance(q["options_json"], str) else q["options_json"]

        total_marks += q_marks
        user_choice = user_answers.get(str(qid))

        is_correct = False
        marks_awarded = 0
        if user_choice is not None and user_choice == correct_idx:
            is_correct = True
            marks_awarded = q_marks
            earned_score += q_marks

        review_list.append(AnswerReview(
            question_id=qid,
            question_text=q["question_text"],
            options=options,
            selected_option_index=user_choice,
            correct_option_index=correct_idx,
            is_correct=is_correct,
            marks_awarded=marks_awarded,
            total_marks=q_marks,
            explanation=q["explanation"] or ""
        ))

    percentage = round((earned_score / total_marks * 100), 1) if total_marks > 0 else 0.0
    status_str = "PASSED" if percentage >= exam["passing_score"] else "FAILED"

    cursor.execute("""
    INSERT INTO submissions (exam_id, user_id, score, total_marks, percentage, status, answers_json, cheat_warnings_count)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?);
    """, (
        exam_id,
        current_user["id"],
        earned_score,
        total_marks,
        percentage,
        status_str,
        json.dumps(user_answers),
        submission_data.cheat_warnings_count
    ))
    db.commit()
    submission_id = cursor.lastrowid

    cursor.execute("SELECT created_at FROM submissions WHERE id = ?;", (submission_id,))
    sub_row = cursor.fetchone()

    return SubmissionResult(
        id=submission_id,
        exam_id=exam["id"],
        exam_title=exam["title"],
        user_id=current_user["id"],
        user_name=current_user["name"],
        score=earned_score,
        total_marks=total_marks,
        percentage=percentage,
        status=status_str,
        cheat_warnings_count=submission_data.cheat_warnings_count,
        submitted_at=str(sub_row["created_at"]),
        review=review_list
    )

@router.get("/my")
def get_my_submissions(current_user: dict = Depends(get_current_user), db: sqlite3.Connection = Depends(get_db)):
    cursor = db.cursor()
    cursor.execute("""
    SELECT 
        s.id, s.exam_id, s.score, s.total_marks, s.percentage, s.status, 
        s.cheat_warnings_count, s.created_at,
        e.title as exam_title, e.category, e.passing_score
    FROM submissions s
    JOIN exams e ON s.exam_id = e.id
    WHERE s.user_id = ?
    ORDER BY s.created_at DESC;
    """, (current_user["id"],))
    rows = cursor.fetchall()

    return [
        {
            "id": r["id"],
            "exam_id": r["exam_id"],
            "exam_title": r["exam_title"],
            "category": r["category"],
            "score": r["score"],
            "total_marks": r["total_marks"],
            "percentage": r["percentage"],
            "status": r["status"],
            "passing_score": r["passing_score"],
            "cheat_warnings_count": r["cheat_warnings_count"],
            "created_at": str(r["created_at"])
        }
        for r in rows
    ]

@router.get("/exam/{exam_id}")
def get_exam_submissions(
    exam_id: int,
    current_user: dict = Depends(require_teacher),
    db: sqlite3.Connection = Depends(get_db)
):
    cursor = db.cursor()
    cursor.execute("""
    SELECT 
        s.id, s.user_id, s.score, s.total_marks, s.percentage, s.status, 
        s.cheat_warnings_count, s.created_at,
        u.name as student_name, u.email as student_email
    FROM submissions s
    JOIN users u ON s.user_id = u.id
    WHERE s.exam_id = ?
    ORDER BY s.created_at DESC;
    """, (exam_id,))
    rows = cursor.fetchall()

    return [
        {
            "id": r["id"],
            "user_id": r["user_id"],
            "student_name": r["student_name"],
            "student_email": r["student_email"],
            "score": r["score"],
            "total_marks": r["total_marks"],
            "percentage": r["percentage"],
            "status": r["status"],
            "cheat_warnings_count": r["cheat_warnings_count"],
            "created_at": str(r["created_at"])
        }
        for r in rows
    ]

@router.get("/{submission_id}", response_model=SubmissionResult)
def get_submission_details(
    submission_id: int,
    current_user: dict = Depends(get_current_user),
    db: sqlite3.Connection = Depends(get_db)
):
    cursor = db.cursor()
    cursor.execute("""
    SELECT s.*, e.title as exam_title, u.name as user_name
    FROM submissions s
    JOIN exams e ON s.exam_id = e.id
    JOIN users u ON s.user_id = u.id
    WHERE s.id = ?;
    """, (submission_id,))
    sub = cursor.fetchone()

    if not sub:
        raise HTTPException(status_code=404, detail="Submission not found")

    # Access check: user must be the submitter or a teacher
    if current_user["role"] != "teacher" and current_user["id"] != sub["user_id"]:
        raise HTTPException(status_code=403, detail="Not authorized to view this result")

    user_answers = json.loads(sub["answers_json"]) if isinstance(sub["answers_json"], str) else sub["answers_json"]

    cursor.execute("""
    SELECT id, question_text, options_json, correct_option_index, marks, explanation
    FROM questions WHERE exam_id = ? ORDER BY id ASC;
    """, (sub["exam_id"],))
    questions = cursor.fetchall()

    review_list = []
    for q in questions:
        qid = q["id"]
        q_marks = q["marks"]
        correct_idx = q["correct_option_index"]
        options = json.loads(q["options_json"]) if isinstance(q["options_json"], str) else q["options_json"]
        user_choice = user_answers.get(str(qid))

        is_correct = (user_choice is not None and user_choice == correct_idx)
        marks_awarded = q_marks if is_correct else 0

        review_list.append(AnswerReview(
            question_id=qid,
            question_text=q["question_text"],
            options=options,
            selected_option_index=user_choice,
            correct_option_index=correct_idx,
            is_correct=is_correct,
            marks_awarded=marks_awarded,
            total_marks=q_marks,
            explanation=q["explanation"] or ""
        ))

    return SubmissionResult(
        id=sub["id"],
        exam_id=sub["exam_id"],
        exam_title=sub["exam_title"],
        user_id=sub["user_id"],
        user_name=sub["user_name"],
        score=sub["score"],
        total_marks=sub["total_marks"],
        percentage=sub["percentage"],
        status=sub["status"],
        cheat_warnings_count=sub["cheat_warnings_count"],
        submitted_at=str(sub["created_at"]),
        review=review_list
    )

@router.get("/overview/stats")
def get_stats_overview(db: sqlite3.Connection = Depends(get_db)):
    cursor = db.cursor()
    cursor.execute("SELECT COUNT(*) FROM exams WHERE is_active = 1;")
    exams_count = cursor.fetchone()[0]

    cursor.execute("SELECT COUNT(*) FROM users WHERE role = 'student';")
    students_count = cursor.fetchone()[0]

    cursor.execute("SELECT COUNT(*) FROM submissions;")
    submissions_count = cursor.fetchone()[0]

    cursor.execute("SELECT COUNT(*) FROM submissions WHERE status = 'PASSED';")
    passed_count = cursor.fetchone()[0]

    pass_rate = round((passed_count / submissions_count * 100), 1) if submissions_count > 0 else 0.0

    return {
        "total_exams": exams_count,
        "total_students": students_count,
        "total_submissions": submissions_count,
        "pass_rate": pass_rate
    }
