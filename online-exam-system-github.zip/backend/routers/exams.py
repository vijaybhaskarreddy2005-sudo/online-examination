import json
import sqlite3
from typing import List
from fastapi import APIRouter, Depends, HTTPException, status
from backend.database import get_db
from backend.auth import get_current_user, require_teacher
from backend.models import ExamCreate, ExamSummary, ExamTakeDetail, QuestionCreate, QuestionPublic, QuestionDetailed

router = APIRouter(prefix="/api/exams", tags=["Exams"])

@router.get("", response_model=List[ExamSummary])
def list_exams(db: sqlite3.Connection = Depends(get_db)):
    cursor = db.cursor()
    cursor.execute("""
    SELECT 
        e.id, e.title, e.description, e.category, e.duration_minutes, e.passing_score,
        e.created_by, e.created_at,
        u.name as creator_name,
        COUNT(q.id) as question_count,
        COALESCE(SUM(q.marks), 0) as total_marks
    FROM exams e
    LEFT JOIN users u ON e.created_by = u.id
    LEFT JOIN questions q ON e.id = q.exam_id
    WHERE e.is_active = 1
    GROUP BY e.id
    ORDER BY e.created_at DESC;
    """)
    rows = cursor.fetchall()

    results = []
    for r in rows:
        results.append({
            "id": r["id"],
            "title": r["title"],
            "description": r["description"] or "",
            "category": r["category"] or "General",
            "duration_minutes": r["duration_minutes"],
            "passing_score": r["passing_score"],
            "created_by": r["created_by"],
            "creator_name": r["creator_name"] or "Faculty",
            "question_count": r["question_count"],
            "total_marks": r["total_marks"],
            "created_at": str(r["created_at"])
        })
    return results

@router.get("/{exam_id}", response_model=ExamTakeDetail)
def get_exam_for_taking(exam_id: int, db: sqlite3.Connection = Depends(get_db)):
    cursor = db.cursor()
    cursor.execute("SELECT * FROM exams WHERE id = ? AND is_active = 1;", (exam_id,))
    exam = cursor.fetchone()
    if not exam:
        raise HTTPException(status_code=404, detail="Exam not found or inactive")

    cursor.execute("SELECT id, question_text, options_json, marks FROM questions WHERE exam_id = ? ORDER BY id ASC;", (exam_id,))
    q_rows = cursor.fetchall()

    questions = []
    total_marks = 0
    for q in q_rows:
        total_marks += q["marks"]
        options = json.loads(q["options_json"]) if isinstance(q["options_json"], str) else q["options_json"]
        questions.append({
            "id": q["id"],
            "question_text": q["question_text"],
            "options": options,
            "marks": q["marks"]
        })

    return {
        "id": exam["id"],
        "title": exam["title"],
        "description": exam["description"] or "",
        "category": exam["category"] or "General",
        "duration_minutes": exam["duration_minutes"],
        "passing_score": exam["passing_score"],
        "questions": questions,
        "total_marks": total_marks
    }

@router.get("/{exam_id}/edit")
def get_exam_for_editing(exam_id: int, current_user: dict = Depends(require_teacher), db: sqlite3.Connection = Depends(get_db)):
    cursor = db.cursor()
    cursor.execute("SELECT * FROM exams WHERE id = ?;", (exam_id,))
    exam = cursor.fetchone()
    if not exam:
        raise HTTPException(status_code=404, detail="Exam not found")

    cursor.execute("SELECT * FROM questions WHERE exam_id = ? ORDER BY id ASC;", (exam_id,))
    q_rows = cursor.fetchall()

    questions = []
    for q in q_rows:
        questions.append({
            "id": q["id"],
            "question_text": q["question_text"],
            "options": json.loads(q["options_json"]),
            "correct_option_index": q["correct_option_index"],
            "marks": q["marks"],
            "explanation": q["explanation"]
        })

    return {
        "id": exam["id"],
        "title": exam["title"],
        "description": exam["description"],
        "category": exam["category"],
        "duration_minutes": exam["duration_minutes"],
        "passing_score": exam["passing_score"],
        "questions": questions
    }

@router.post("", status_code=status.HTTP_201_CREATED)
def create_exam(exam_data: ExamCreate, current_user: dict = Depends(require_teacher), db: sqlite3.Connection = Depends(get_db)):
    cursor = db.cursor()
    cursor.execute("""
    INSERT INTO exams (title, description, category, duration_minutes, passing_score, created_by)
    VALUES (?, ?, ?, ?, ?, ?);
    """, (
        exam_data.title.strip(),
        exam_data.description.strip() if exam_data.description else "",
        exam_data.category.strip() or "General",
        exam_data.duration_minutes,
        exam_data.passing_score,
        current_user["id"]
    ))
    exam_id = cursor.lastrowid

    if exam_data.questions:
        q_records = []
        for q in exam_data.questions:
            q_records.append((
                exam_id,
                q.question_text.strip(),
                json.dumps(q.options),
                q.correct_option_index,
                q.marks,
                q.explanation or ""
            ))
        cursor.executemany("""
        INSERT INTO questions (exam_id, question_text, options_json, correct_option_index, marks, explanation)
        VALUES (?, ?, ?, ?, ?, ?);
        """, q_records)

    db.commit()
    return {"message": "Exam created successfully", "exam_id": exam_id}

@router.post("/{exam_id}/questions", status_code=status.HTTP_201_CREATED)
def add_question(exam_id: int, question: QuestionCreate, current_user: dict = Depends(require_teacher), db: sqlite3.Connection = Depends(get_db)):
    cursor = db.cursor()
    cursor.execute("SELECT id FROM exams WHERE id = ?;", (exam_id,))
    if not cursor.fetchone():
        raise HTTPException(status_code=404, detail="Exam not found")

    cursor.execute("""
    INSERT INTO questions (exam_id, question_text, options_json, correct_option_index, marks, explanation)
    VALUES (?, ?, ?, ?, ?, ?);
    """, (
        exam_id,
        question.question_text.strip(),
        json.dumps(question.options),
        question.correct_option_index,
        question.marks,
        question.explanation or ""
    ))
    db.commit()
    return {"message": "Question added successfully", "question_id": cursor.lastrowid}

@router.delete("/{exam_id}")
def delete_exam(exam_id: int, current_user: dict = Depends(require_teacher), db: sqlite3.Connection = Depends(get_db)):
    cursor = db.cursor()
    cursor.execute("SELECT id FROM exams WHERE id = ?;", (exam_id,))
    if not cursor.fetchone():
        raise HTTPException(status_code=404, detail="Exam not found")

    cursor.execute("DELETE FROM exams WHERE id = ?;", (exam_id,))
    db.commit()
    return {"message": "Exam deleted successfully"}
