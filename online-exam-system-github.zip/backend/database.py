import sqlite3
import json
import os
import hashlib
import secrets
from datetime import datetime

DB_PATH = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "exams.db")

def hash_pw(password: str) -> str:
    salt = secrets.token_hex(16)
    hashed = hashlib.sha256((salt + password).encode("utf-8")).hexdigest()
    return f"{salt}:{hashed}"

def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON;")
    try:
        yield conn
    finally:
        conn.close()

def init_db():
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        email TEXT UNIQUE NOT NULL,
        password_hash TEXT NOT NULL,
        role TEXT NOT NULL CHECK(role IN ('student', 'teacher')),
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    );
    """)

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS exams (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        title TEXT NOT NULL,
        description TEXT,
        category TEXT DEFAULT 'General',
        duration_minutes INTEGER NOT NULL DEFAULT 15,
        passing_score INTEGER NOT NULL DEFAULT 60,
        created_by INTEGER NOT NULL,
        is_active INTEGER DEFAULT 1,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (created_by) REFERENCES users (id) ON DELETE CASCADE
    );
    """)

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS questions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        exam_id INTEGER NOT NULL,
        question_text TEXT NOT NULL,
        options_json TEXT NOT NULL,
        correct_option_index INTEGER NOT NULL,
        marks INTEGER DEFAULT 1,
        explanation TEXT DEFAULT '',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (exam_id) REFERENCES exams (id) ON DELETE CASCADE
    );
    """)

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS submissions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        exam_id INTEGER NOT NULL,
        user_id INTEGER NOT NULL,
        start_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        end_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        score INTEGER NOT NULL,
        total_marks INTEGER NOT NULL,
        percentage REAL NOT NULL,
        status TEXT NOT NULL CHECK(status IN ('PASSED', 'FAILED')),
        answers_json TEXT NOT NULL,
        cheat_warnings_count INTEGER DEFAULT 0,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (exam_id) REFERENCES exams (id) ON DELETE CASCADE,
        FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE
    );
    """)

    conn.commit()

    # Seed initial users & exams if empty
    seed_initial_data(conn)
    conn.close()

def seed_initial_data(conn):
    cursor = conn.cursor()
    cursor.execute("SELECT COUNT(*) FROM users;")
    user_count = cursor.fetchone()[0]

    if user_count == 0:
        teacher_pw = hash_pw("teacher123")
        student_pw = hash_pw("student123")

        cursor.execute("""
        INSERT INTO users (name, email, password_hash, role)
        VALUES 
        ('Dr. Sarah Connor', 'teacher@exam.com', ?, 'teacher'),
        ('Alex Morgan', 'student@exam.com', ?, 'student');
        """, (teacher_pw, student_pw))
        conn.commit()

        teacher_id = 1
        student_id = 2

        # Create Sample Exam 1: Python & FastAPI
        cursor.execute("""
        INSERT INTO exams (title, description, category, duration_minutes, passing_score, created_by)
        VALUES (?, ?, ?, ?, ?, ?);
        """, (
            "Python & FastAPI Backend Engineering",
            "Comprehensive test evaluating core Python programming, asynchronous execution, FastAPI routing, and REST architecture.",
            "Backend Development",
            15,
            70,
            teacher_id
        ))
        exam1_id = cursor.lastrowid

        exam1_questions = [
            (
                exam1_id,
                "In FastAPI, which HTTP status code is returned by default for successful POST operations unless specified otherwise?",
                json.dumps(["200 OK", "201 Created", "204 No Content", "202 Accepted"]),
                0,
                2,
                "FastAPI returns status code 200 by default unless you declare status_code=201 in the path operation decorator."
            ),
            (
                exam1_id,
                "What is the primary benefit of declaring route handlers with 'async def' in FastAPI?",
                json.dumps([
                    "It automatically creates separate operating system processes",
                    "It allows non-blocking I/O operations using the Python asyncio event loop",
                    "It compiles Python code into native machine code",
                    "It disables the Python Global Interpreter Lock (GIL)"
                ]),
                1,
                2,
                "async def enables cooperative multitasking where async I/O operations yield control back to the event loop."
            ),
            (
                exam1_id,
                "What is the time complexity of looking up a key in a standard Python dictionary on average?",
                json.dumps(["O(n)", "O(log n)", "O(1)", "O(n log n)"]),
                2,
                1,
                "Python dictionaries are implemented using hash tables with average case O(1) lookup time."
            ),
            (
                exam1_id,
                "Which Pydantic class is standardly subclassed to define request body schemas in FastAPI?",
                json.dumps(["pydantic.DataClass", "pydantic.BaseModel", "pydantic.SchemaModel", "pydantic.ModelView"]),
                1,
                1,
                "BaseModel from pydantic is the foundational class for data validation and parsing in FastAPI."
            ),
            (
                exam1_id,
                "What does Python's 'yield' keyword do when used inside a function definition?",
                json.dumps([
                    "Immediately terminates the entire program",
                    "Turns the function into a generator that returns values lazily",
                    "Pauses thread execution for a specified duration",
                    "Locks a shared variable across threads"
                ]),
                1,
                2,
                "yield produces an item from a generator iterator and suspends function execution until the next item is requested."
            ),
            (
                exam1_id,
                "Which HTTP header is commonly used in REST APIs to pass a Bearer JWT authentication token?",
                json.dumps(["Proxy-Authenticate", "X-Auth-Token", "Authorization", "Authentication"]),
                2,
                1,
                "The standard HTTP Authorization header is formatted as 'Authorization: Bearer <token>'."
            )
        ]

        cursor.executemany("""
        INSERT INTO questions (exam_id, question_text, options_json, correct_option_index, marks, explanation)
        VALUES (?, ?, ?, ?, ?, ?);
        """, exam1_questions)

        # Create Sample Exam 2: React & Modern Web
        cursor.execute("""
        INSERT INTO exams (title, description, category, duration_minutes, passing_score, created_by)
        VALUES (?, ?, ?, ?, ?, ?);
        """, (
            "React.js & Modern Web Development",
            "Test your knowledge of React hooks, component lifecycle, virtual DOM, JSX, and frontend state management.",
            "Frontend Development",
            12,
            60,
            teacher_id
        ))
        exam2_id = cursor.lastrowid

        exam2_questions = [
            (
                exam2_id,
                "Which React hook is specifically designed to perform side effects such as data fetching or subscriptions?",
                json.dumps(["useState", "useMemo", "useEffect", "useCallback"]),
                2,
                2,
                "useEffect runs side effects after component render cycles based on its dependency array."
            ),
            (
                exam2_id,
                "Why should you provide a unique 'key' prop when rendering a dynamic list of elements in React?",
                json.dumps([
                    "To apply unique CSS styles to each element automatically",
                    "To help React's virtual DOM diffing algorithm identify which items have changed, added, or removed",
                    "It is required by the JavaScript ES6 specification",
                    "To encrypt the DOM node contents in production"
                ]),
                1,
                2,
                "Keys give elements a stable identity across re-renders for efficient DOM reconciliation."
            ),
            (
                exam2_id,
                "What is the purpose of React's Virtual DOM?",
                json.dumps([
                    "To replace the browser's native DOM entirely with WebAssembly",
                    "To minimize expensive direct browser DOM manipulations through efficient in-memory diffing",
                    "To allow offline local database storage in the browser",
                    "To render 3D canvas animations without GPU drivers"
                ]),
                1,
                2,
                "The virtual DOM computes minimum necessary changes in memory before batching updates to the real DOM."
            ),
            (
                exam2_id,
                "What happens when you invoke a state updater function returned by useState with the same value as the current state?",
                json.dumps([
                    "React triggers an infinite re-render loop",
                    "React bails out without re-rendering the component or triggering effects",
                    "React throws a TypeError in strict mode",
                    "React resets the state to null"
                ]),
                1,
                2,
                "React uses Object.is comparison; if identical, it bails out from re-rendering for performance."
            ),
            (
                exam2_id,
                "Which hook should you use to memoize an expensive calculation so it only recalculates when dependencies change?",
                json.dumps(["useRef", "useMemo", "useReducer", "useLayoutEffect"]),
                1,
                2,
                "useMemo caches the calculated result value between re-renders until one of its dependencies changes."
            )
        ]

        cursor.executemany("""
        INSERT INTO questions (exam_id, question_text, options_json, correct_option_index, marks, explanation)
        VALUES (?, ?, ?, ?, ?, ?);
        """, exam2_questions)

        # Pre-seed sample submission
        sample_answers = {"1": 0, "2": 1, "3": 2, "4": 1, "5": 1, "6": 0}
        cursor.execute("""
        INSERT INTO submissions (exam_id, user_id, score, total_marks, percentage, status, answers_json, cheat_warnings_count)
        VALUES (?, ?, 8, 10, 80.0, 'PASSED', ?, 0);
        """, (exam1_id, student_id, json.dumps(sample_answers)))

        conn.commit()
