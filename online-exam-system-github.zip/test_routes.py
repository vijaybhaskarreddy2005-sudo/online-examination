import sys
import os
import json

PROJECT_DIR = r"C:\Users\vijay\.gemini\antigravity\scratch\online-exam-system"
if PROJECT_DIR not in sys.path:
    sys.path.insert(0, PROJECT_DIR)

from backend.database import get_db, init_db
from backend.routers.auth import register, login, demo_login
from backend.routers.exams import list_exams, get_exam_for_taking, create_exam
from backend.routers.submissions import submit_exam, get_my_submissions, get_stats_overview
from backend.models import UserRegister, UserLogin, ExamCreate, QuestionCreate, ExamSubmissionRequest

def test_all():
    print("[*] Initializing Database...")
    init_db()

    gen = get_db()
    db = next(gen)

    try:
        # 1. Test Demo Logins
        print("[1] Testing Demo Logins...")
        student_res = demo_login("student", db)
        print("    -> Student:", student_res["user"]["name"], student_res["user"]["email"])
        teacher_res = demo_login("teacher", db)
        print("    -> Teacher:", teacher_res["user"]["name"], teacher_res["user"]["email"])

        # 2. Test List Exams
        print("[2] Testing List Exams...")
        exams = list_exams(db)
        print(f"    -> Found {len(exams)} active exams:")
        for e in exams:
            print(f"       - [{e['category']}] {e['title']} ({e['question_count']} questions, {e['duration_minutes']}m)")

        # 3. Test Student Taking Exam Detail (answers stripped)
        print("[3] Testing Exam Taking Fetch (Questions without answers)...")
        exam_detail = get_exam_for_taking(exams[0]["id"], db)
        print(f"    -> Retrieved exam '{exam_detail['title']}' with {len(exam_detail['questions'])} questions.")
        q1 = exam_detail["questions"][0]
        assert "correct_option_index" not in q1, "Security leak: correct_option_index found in public endpoint!"
        print(f"    -> Security check passed: answers stripped from student payload.")

        # 4. Test Student Submission & Auto-Grading
        print("[4] Testing Exam Submission & Instant Auto-Grading...")
        student_user = student_res["user"]
        submission_payload = ExamSubmissionRequest(
            answers={"1": 0, "2": 1, "3": 2, "4": 1, "5": 1, "6": 2},
            cheat_warnings_count=1
        )
        result = submit_exam(exams[0]["id"], submission_payload, student_user, db)
        print(f"    -> Result: Score {result.score}/{result.total_marks} ({result.percentage}%) - Status: {result.status}")
        print(f"    -> Verified Question Reviews: {len(result.review)} questions reviewed with explanations.")

        # 5. Test Teacher Exam Creation
        print("[5] Testing Teacher Exam Creation...")
        teacher_user = teacher_res["user"]
        new_exam_data = ExamCreate(
            title="Database Architecture & SQL Query Optimization",
            description="Intermediate test on indexing, query planning, ACID properties, and transactions.",
            category="Database Systems",
            duration_minutes=20,
            passing_score=75,
            questions=[
                QuestionCreate(
                    question_text="Which index type is optimal for range queries like BETWEEN or comparison operators?",
                    options=["Hash Index", "B-Tree Index", "Bitmap Index", "Full-Text Index"],
                    correct_option_index=1,
                    marks=2,
                    explanation="B-Tree indexes keep data sorted and allow logarithmic time searches, sequential access, and range queries."
                ),
                QuestionCreate(
                    question_text="In relational databases, what does the 'I' in ACID stand for?",
                    options=["Integrity", "Iteration", "Isolation", "Indexing"],
                    correct_option_index=2,
                    marks=1,
                    explanation="Isolation ensures concurrent execution of transactions leaves the database in the same state as if executed serially."
                )
            ]
        )
        created = create_exam(new_exam_data, teacher_user, db)
        print(f"    -> Exam created with ID: {created['exam_id']}")

        # 6. Test Overview Stats
        print("[6] Testing System Stats Overview...")
        stats = get_stats_overview(db)
        print(f"    -> Overview: Exams={stats['total_exams']}, Students={stats['total_students']}, Submissions={stats['total_submissions']}, Pass Rate={stats['pass_rate']}%")

        print("\n" + "=" * 60)
        print("  ALL ONLINE EXAMINATION BACKEND TESTS PASSED (100%)  ")
        print("=" * 60)
    finally:
        gen.close()

if __name__ == "__main__":
    test_all()
