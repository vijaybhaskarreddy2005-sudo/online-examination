import sys
import os
import uvicorn

# Ensure the project directory is on sys.path
PROJECT_DIR = os.path.dirname(os.path.abspath(__file__))
if PROJECT_DIR not in sys.path:
    sys.path.insert(0, PROJECT_DIR)

from backend.database import init_db

def main():
    print("=" * 60)
    print("      ONLINE EXAMINATION SYSTEM (React + FastAPI)      ")
    print("=" * 60)
    print("[*] Initializing Database & Seed Assessments...")
    init_db()
    print("[+] Database ready: exams.db")
    print("\n[+] Default Demo Accounts:")
    print("    - Faculty / Teacher: teacher@exam.com | teacher123")
    print("    - Student:           student@exam.com | student123")
    print("\n[+] Starting Server at:  http://127.0.0.1:8000")
    print("[+] Interactive API Docs: http://127.0.0.1:8000/docs")
    print("=" * 60 + "\n")

    uvicorn.run("backend.main:app", host="127.0.0.1", port=8000, reload=True)

if __name__ == "__main__":
    main()
