import React, { useState, useEffect } from 'react';
import { api } from './api';

export default function App() {
  const [user, setUser] = useState(null);
  const [exams, setExams] = useState([]);
  const [view, setView] = useState('dashboard');

  useEffect(() => {
    async function loadData() {
      try {
        if (api.token) {
          const me = await api.request('/auth/me');
          setUser(me);
        }
        const examList = await api.request('/exams');
        setExams(examList);
      } catch (e) {
        console.error(e);
      }
    }
    loadData();
  }, []);

  return (
    <div className="min-h-screen bg-slate-50 text-slate-800 font-sans">
      <header className="bg-white border-b border-slate-200 h-16 flex items-center justify-between px-6">
        <h1 className="text-xl font-bold text-indigo-600">ExamPulse</h1>
        <div>
          {user ? (
            <span className="text-sm font-semibold">{user.name} ({user.role})</span>
          ) : (
            <span className="text-xs text-slate-500">FastAPI + React Examination System</span>
          )}
        </div>
      </header>
      <main className="max-w-7xl mx-auto p-6">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {exams.map(exam => (
            <div key={exam.id} className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
              <span className="text-xs font-bold text-indigo-600 uppercase">{exam.category}</span>
              <h2 className="text-lg font-bold mt-1">{exam.title}</h2>
              <p className="text-xs text-slate-500 mt-2">{exam.description}</p>
              <div className="mt-4 pt-4 border-t border-slate-100 flex justify-between text-xs">
                <span>Duration: {exam.duration_minutes}m</span>
                <span>Pass: {exam.passing_score}%</span>
              </div>
            </div>
          ))}
        </div>
      </main>
    </div>
  );
}
