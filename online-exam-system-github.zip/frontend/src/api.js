const API_BASE = '/api';

export const api = {
  token: localStorage.getItem('exam_token') || '',
  setToken(t) {
    this.token = t;
    if (t) localStorage.setItem('exam_token', t);
    else localStorage.removeItem('exam_token');
  },
  async request(endpoint, credentials = {}) {
    const headers = { 'Content-Type': 'application/json', ...(credentials.headers || {}) };
    if (this.token) {
      headers['Authorization'] = `Bearer ${this.token}`;
    }
    const res = await fetch(`${API_BASE}${endpoint}`, { ...credentials, headers });
    if (!res.ok) {
      const err = await res.json().catch(() => ({ detail: 'Request failed' }));
      throw new Error(err.detail || 'Network error');
    }
    return res.json();
  }
};
