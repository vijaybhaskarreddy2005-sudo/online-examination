@echo off
echo Opening Online Examination System in Visual Studio Code...
start "" "%LOCALAPPDATA%\Programs\Microsoft VS Code\Code.exe" "%~dp0"
exit
