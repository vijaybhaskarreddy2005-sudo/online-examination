# Online Examination System (React + FastAPI)

A full-stack, real-time Online Examination platform built with **React** and **FastAPI**, featuring timed examinations, proctoring/tab-switch violation detection, instant auto-grading, detailed scorecards with faculty explanations, and a faculty exam builder & gradebook.

---

## 🚀 Quick Start (Instant Run)

Everything needed (Python 3.14, FastAPI, Uvicorn, SQLite, React SPA) runs in a single command without requiring Node.js:

```bash
cd C:\Users\vijay\.gemini\antigravity\scratch\online-exam-system
python run.py
```

Or simply double-click `start.bat`.

Then open your browser at:
- **Web App Application**: [http://127.0.0.1:8000](http://127.0.0.1:8000)
- **FastAPI Interactive API Docs (Swagger UI)**: [http://127.0.0.1:8000/docs](http://127.0.0.1:8000/docs)

---

## 👥 Default Demo Credentials

You can test either role immediately with **1-click quick login buttons** in the app header, or use the following credentials:

| Role | Email | Password | Permissions |
|---|---|---|---|
| **Faculty / Teacher** | `teacher@exam.com` | `teacher123` | Create exams, add questions, view all student submissions & gradebook, delete exams |
| **Student** | `student@exam.com` | `student123` | Browse exams, take timed tests with proctor monitor, view scorecards & history |

---

## 🌟 Key Features

### 🎓 1. Student Examination Engine
- **Timed Assessment**: Live countdown timer with auto-submit when time expires (visual warning when < 2 minutes left).
- **Interactive Question Palette**:
  - Color-coded question states: **Answered** (Green), **Flagged for Review** (Orange), and **Unanswered** (Gray).
  - Quick-jump navigation across any question in the exam.
- **Proctoring Anti-Cheat Monitor**:
  - Detects tab switching and window blur in real-time.
  - Warns the candidate with alert banners and logs violations to the server.
- **Instant Auto-Grading**:
  - Immediate calculation of marks, percentage, and Pass/Fail status based on exam threshold.
- **Detailed Performance Scorecard**:
  - Question-by-question breakdown showing candidate's choice vs. correct answer.
  - Explanatory rationale provided for each question by faculty.

### 👩‍🏫 2. Faculty / Administrator Portal
- **Interactive Exam Builder**:
  - Create custom exams with title, category, duration in minutes, and passing score %.
  - Add multiple-choice questions (MCQs) with 4 options, designate correct option, marks, and explanations.
- **Student Gradebook & Analytics**:
  - Track student attempts, total scores, percentages, timestamps, and anti-cheat violation counts.
  - Inspect any student's individual answer sheet.
- **Exam Management**:
  - Real-time catalog overview, deletion, and question count monitoring.

### 🔐 3. Backend Architecture (FastAPI + SQLite)
- **FastAPI**: Asynchronous REST API with automatic OpenAPI documentation.
- **JWT Authentication**: Secure token-based authentication with role-based access control (`student` vs. `teacher`).
- **SQLite Database**: Local, zero-configuration database pre-seeded with real engineering certification tests.
- **Clean Anti-Cheating API Design**:
  - When students fetch an active exam, correct answers are stripped server-side to prevent inspecting network payloads.
  - Correct answers are only evaluated and revealed upon submission or to authenticated teachers.

---

## 📁 Project Structure

```text
online-exam-system/
│
├── backend/
│   ├── auth.py                  # JWT creation, validation, password hashing
│   ├── database.py              # SQLite schemas, connection, initial seed data
│   ├── models.py                # Pydantic schemas for requests and responses
│   ├── main.py                  # FastAPI application & static mounting
│   └── routers/
│       ├── auth.py              # Register, login, demo-login, user profile
│       ├── exams.py             # CRUD endpoints for exams and questions
│       └── submissions.py       # Submit test, auto-grading, student history, gradebook
│
├── static/
│   └── index.html               # Modern React 18 SPA with Tailwind CSS & live exam taker
│
├── frontend/                    # Decoupled React source for Vite development
│   ├── src/
│   │   ├── api.js               # API client wrapper with JWT header injection
│   │   ├── App.jsx              # Main React component
│   │   └── main.jsx             # React entrypoint
│   ├── package.json             # NPM dependencies (Vite, React 18, Tailwind)
│   └── vite.config.js           # Vite dev server configuration with proxy
│
├── run.py                       # Master one-click startup script
├── start.bat                    # Windows batch launcher
├── exams.db                     # SQLite database (auto-created on startup)
└── README.md                    # Documentation
```

---

## 📡 REST API Reference

| Method | Endpoint | Description | Auth Required |
|---|---|---|---|
| `POST` | `/api/auth/register` | Register new student or teacher | No |
| `POST` | `/api/auth/login` | Login and receive Bearer JWT | No |
| `POST` | `/api/auth/demo-login/{role}` | Instant 1-click login for demo | No |
| `GET` | `/api/auth/me` | Fetch current logged-in user profile | Yes |
| `GET` | `/api/exams` | List all active exams with summaries | No |
| `GET` | `/api/exams/{id}` | Get exam questions (without answers) | No |
| `POST` | `/api/exams` | Create a new exam with questions | Teacher |
| `DELETE` | `/api/exams/{id}` | Delete exam | Teacher |
| `POST` | `/api/submissions/exam/{id}` | Submit answers, auto-grade & generate scorecard | Student |
| `GET` | `/api/submissions/my` | View current student's past exam attempts | Student |
| `GET` | `/api/submissions/exam/{id}` | View all student attempts for an exam (Gradebook) | Teacher |
| `GET` | `/api/submissions/{id}` | View detailed scorecard & question explanations | Owner / Teacher |
| `GET` | `/api/submissions/overview/stats` | High-level system statistics | No |
